const { Router } = require('express');
const { storeUsuario } = require('../controller/cadastroController');
 
const router = Router();
 
router.post('/store/usuario', storeUsuario);
 
module.exports = router;