var botao = document.getElementById('botao')

async function handleSubmit(event) {
    event.preventDefault();

 
    // Pegar os valores do formulário
    var desc_receita = document.getElementById('postContent').value;
    var authorName = document.getElementById('authorName').value;
    var postContent = document.getElementById('postContent').value;

    var user_id = 1

    const data = {
        user_id,
        desc_receita
    }

    const response = await fetch('http://localhost:3001/api/store/receita_criar', {
        method: 'POST',
        headers: {"Content-type": "application/json;charset=UTF-8"},
        body: JSON.stringify(data)
    })

    let content = await response.json()

    if (content.success) {
        
        // Criar o elemento de postagem
        var postElement = document.createElement('div');
        postElement.classList.add('post');
     
        // Construir o HTML da postagem
        postElement.innerHTML = `
            <p class="author">${authorName}</p>
            <p class="content">${postContent}</p>
        `;
     
        // Adicionar a postagem à lista de postagens
        document.getElementById('postList').appendChild(postElement);
     
        // Limpar os campos do formulário
        document.getElementById('postContent').value = '';
        document.getElementById('authorName').value = '';

        alert("funcionou")

    } else {
        alert("erro")
    }
 

}